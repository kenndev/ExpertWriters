<template>
    <Admin>
        <div class="mt-4 flex flex-wrap">
            <div class="mb-12 w-full px-4">
                <CardDatatable color="dark" />
            </div>
        </div>
    </Admin>
</template>
<script setup>
import Admin from "@/Layouts/Admin.vue";
import CardDatatable from "@/Components/Cards/CardDatatable.vue";
</script>
