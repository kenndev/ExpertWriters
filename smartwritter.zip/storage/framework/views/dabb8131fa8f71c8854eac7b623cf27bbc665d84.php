<?php echo e($slot); ?>

<?php /**PATH D:\workspace\laravel\smartwritter\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>